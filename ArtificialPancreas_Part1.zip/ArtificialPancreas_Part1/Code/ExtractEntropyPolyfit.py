#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import pandas as pd
import numpy as np
from tsfresh  import extract_features
import matplotlib.pyplot as plt
from matplotlib.pyplot import figure

cgmSeriesLunch_1 = pd.read_csv(r'/home/bhargavi/Downloads/DataFolder/CGMSeriespreprocessed4.csv' )
no_of_rows = cgmSeriesLunch_1.shape[0]
no_of_cols = cgmSeriesLunch_1.shape[1]

result = cgmSeriesLunch_1.T
#print(result)
cols = []
for i in range(0, no_of_rows) :
    cols.append(str(i))
result.columns = cols

cgmSeriesLunch_1 = cgmSeriesLunch_1.stack()
cgmSeriesLunch_1.index.rename([ 'id', 'time' ], inplace = True )
cgmSeriesLunch_1 = cgmSeriesLunch_1.reset_index()
f = extract_features( cgmSeriesLunch_1, column_id = "id", column_sort = "time" )

print(f['0__sample_entropy'])
temp = f['0__sample_entropy']
temp.to_csv(r'entropy4.csv',sep='\t', encoding='utf-8')

colid = []
print(result)
for i in range(0, no_of_cols) :
    colid.append(i+1)
x = np.array(colid)
#print(x)
#print(no_of_rows)
fftmatrix = []
#
for i in range(0, no_of_rows) :
    y = np.array(result[str(i)])
    print(y)
    polyres = np.polyfit(x, y, 5)  
    fftmatrix.append(polyres.tolist())
    
fft = pd.DataFrame(fftmatrix, columns=['coeff5', 'coeff4', 'coeff3','coeff2','coeff1', 'coeff0'])
fft.to_csv(r'polyfit4.csv',sep='\t', encoding='utf-8')
print(fft)

